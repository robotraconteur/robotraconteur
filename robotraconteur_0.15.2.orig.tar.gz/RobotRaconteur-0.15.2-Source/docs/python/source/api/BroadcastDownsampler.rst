Broadcast Dowsampler
====================

.. autoclass:: RobotRaconteur.BroadcastDownsampler
    :members:

.. autoclass:: RobotRaconteur.BroadcastDownsamplerStep
    :members: