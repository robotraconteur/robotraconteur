function delete(c)

RobotRaconteurMex('deletelistener',c.objecttype,c.objectid,c.connectionid);