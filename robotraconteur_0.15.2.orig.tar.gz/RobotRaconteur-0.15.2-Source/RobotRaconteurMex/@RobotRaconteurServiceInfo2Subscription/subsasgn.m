function  obj = subsasgn( obj, S, value )
RobotRaconteurMex('subsasgn',obj.rrobjecttype,obj.rrstubid,S,value);

end

