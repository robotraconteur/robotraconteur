function disp(c)
%disp Display information about object
    display(c)